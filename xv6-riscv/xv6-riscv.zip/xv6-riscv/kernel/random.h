#ifndef RANDOM_H
#define RANDOM_H

void rand_init(int);
int scaled_random(int, int);

#endif
